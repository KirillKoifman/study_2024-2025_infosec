---
marp: true
title: Marp
paginate: true
backgroundColor: grey
---

## Этап проекта №2
### Установка DVWA
<br/>
дисциплина:  Информационная безопасность

Студент: Койфман Кирилл Дмитриевич
Группа: НПИбд-01-21

---

__Цель работы__
Установите DVWA в гостевую систему к Kali Linux.

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_1.png)

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_2.png)

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_3.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_4.png)

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_5.png)

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage2/Screenshots/Screenshot_7.png)

---
## Спасибо за внимание!