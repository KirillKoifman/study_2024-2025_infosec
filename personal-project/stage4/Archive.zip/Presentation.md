---
marp: true
title: Marp
paginate: true
backgroundColor: grey
---

## Этап проекта №4
### Использование nikto
<br/>
дисциплина:  Информационная безопасность

Студент: Койфман Кирилл Дмитриевич
Группа: НПИбд-01-21

---

__Цель работы__
Установить базовый сканер безопасности веб-сервера nikto в гостевую систему к Kali Linux и использовать его для сканирования нескольких веб-приложений.

---
## Ход работы
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_1.png)

---

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_2.png)

---

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_3.png)

---

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_4.png)

---
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_5.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_6.png)

---
## Спасибо за внимание!