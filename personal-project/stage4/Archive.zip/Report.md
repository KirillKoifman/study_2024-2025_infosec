# РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ

### Факультет физико-математических и естественных наук 

<br/>
<br/>
<br/>
<br/>

ОТЧЕТ
Этап проекта №4
===============
## Тема: Использование nikto

<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
дисциплина:  Информационная безопасность

Студент: Койфман Кирилл Дмитриевич

Группа: НПИбд-01-21

<br/>
<br/>
<br/>
<br/>

## Введение.
### Цель работы.
Установить базовый сканер безопасности веб-сервера nikto в гостевую систему к Kali Linux и использовать его для сканирования нескольких веб-приложений.

## Ход работы
Для начала, запусти виртуальную машину Kali Linux, установим сканер nikto и ознакомимся со справочной информацией (рис.1 - рис.3):

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_1.png)
<br/>*РИС.1(nikto установлен)*

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_2.png)
<br/>*РИС.2(справка по сканеру nikto)*

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_3.png)
<br/>*РИС.3(сканер исправен и готов к использованию)*

Теперь проведём сканирование нескольких веб-приложений (рис.4 - рис.6):

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_4.png)
<br/>*РИС.4*

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_5.png)
<br/>*РИС.5*

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/personal-project/stage4/Screenshots/Screenshot_6.png)
<br/>*РИС.6*

## Заключение
В ходе продеданной лабораторной работы основная цель была достигнута.