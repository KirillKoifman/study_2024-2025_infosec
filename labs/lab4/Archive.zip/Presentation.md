---
marp: true
title: Marp
paginate: true
backgroundColor: grey
---

## Лабораторная работа №4
### Дискреционное разграничение прав в Linux. Расширенные атрибуты
<br/>
дисциплина:  Информационная безопасность

Студент: Койфман Кирилл Дмитриевич
Группа: НПИбд-01-21

---

__Цель работы__
Получение практических навыков работы в консоли с расширенными атрибутами файлов.
__Задачи__
1. Проведём последовательность тестов над файлами с применением расширенного атрибута -a. 

2. Проведём последовательность тестов над файлами с применением расширенного атрибута -i. 

---
## 1 задание
Проведём последовательность тестов над файлами после установки атрибута -a:

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_1.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_2.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_3.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_4.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_5.png)

---
## 1 задание
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_6.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_7.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_8.png)

---
## 1 задание
![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_9.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_10.png)

---
## 2 задание
Проведём последовательность тестов над файлами после установки атрибута -i:

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_11.png)

![pic](https://raw.githubusercontent.com/KirillKoifman/study_2024-2025_infosec/master/labs/lab4/Screenshots/Screenshot_12.png)

---
## Спасибо за внимание!
